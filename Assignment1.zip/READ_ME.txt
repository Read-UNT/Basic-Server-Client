To compile and run server:
Compilation: gcc -o server server.c
Execution  : ./server "Insert_Port_Of_Choice"

To compile and run client:
Compilation: gcc -o client client.c
Execution  : ./client "Insert_Port_of_Choice"

Both set to run on CSCE01 for the server, and any other machine for the client.